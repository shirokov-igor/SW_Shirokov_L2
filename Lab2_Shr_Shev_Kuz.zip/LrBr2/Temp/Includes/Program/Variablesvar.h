/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1761051174_4_
#define _BUR_1761051174_4_

#include <bur/plctypes.h>

/* Constants */
#ifdef _REPLACE_CONST
#else
#endif


/* Variables */
_BUR_LOCAL struct DoorStateMachine doorSM;
_BUR_LOCAL struct LedStateMachine ledSM;
_BUR_LOCAL struct DriveStateMachine driveSM;





__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/Program/Variables.var\\\" scope \\\"local\\\"\\n\"");
__asm__(".ascii \"iecfile \\\"Logical/Library/Library.fun\\\" scope \\\"global\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1761051174_4_ */

